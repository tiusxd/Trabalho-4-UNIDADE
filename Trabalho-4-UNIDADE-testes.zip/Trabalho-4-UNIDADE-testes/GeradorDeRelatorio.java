import java.util.ArrayList;

public class GeradorDeRelatorio{
    public static String relatorioMedias(Escola escola){return null;}
    public static String relatorioAprovados(Escola escola){return null;}
    public static String relatorioReprovados(Escola escola){return null;}
    public static String relatorioDocentes(Escola escola){return null;}
}
