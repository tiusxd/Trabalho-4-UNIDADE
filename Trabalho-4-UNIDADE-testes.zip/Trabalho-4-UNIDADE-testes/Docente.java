import java.util.ArrayList;

public class Docente extends Entidade{
    private ArrayList<Integer> turmas;
    public Docente() {
    }

    public Docente(String base) {
        super(base);
    }

    @Override
    public String toCsv() {
        // TODO Auto-generated method stub
        return null;
    }
}
